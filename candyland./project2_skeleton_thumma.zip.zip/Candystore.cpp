#include "Candystore.h"
#include <fstream>
#include <sstream>


Candystore::Candystore()
{
    _storeName = "";
    Candy _storeStock[_MAX_CANDIES];
};

Candystore::Candystore(string name, Candy _stock[], const int CANDY_ARR_SIZE){
    _storeName=name;
    _candy_count=0;
    for(int i=0;i<CANDY_ARR_SIZE&&_candy_count<_MAX_CANDIES;i++){
        if(_stock[i].name!=""){        
            _storeStock[_candy_count++] = _stock[i];
        }
    }
};

string Candystore::getName(){
    return _storeName;
}
void Candystore::setName(string name){
    _storeName=name;
}
//void Candystore::addCandy(Candy candy){}
    //Same as player class
//void Candystore::removeCandy(string name){}
    //Same as player class
    //just update _candystock

//Candy Candystore::findCandy(string candyname){}
    //Same as player class

void Candystore::displayCandy(){
 string name;
    cout << "Here is a list of candies in the candy store:" << endl;
    for (int i = 0; i < _MAX_CANDIES; i++){
        cout << "Name: " << _storeStock[i].name << endl
        << "Description: "<< _storeStock[i].description << endl
        << "Effect: "<< _storeStock[i].effect_type << endl
        << "Effect value: "<< _storeStock[i].effect_value << endl
        << "Candy type: "<< _storeStock[i].candy_type << endl
        << "Price: "<< _storeStock[i].price << endl;
        if(i!=_MAX_CANDIES-1){
            cout << "----------------------------------" << endl;
        }
    }
    return;
}

