#include "Player.h"
#include <iostream>
#include <vector>

using namespace std;

Player::Player()
{
    _name = "";
    _character = "";
    _stamina = 0;
    _gold = 0.00;
    _effect = "";
    _candy_amount = 0;
};

Player::Player(string name, string character, int stam, double gold, string effect, Candy candy_array[], const int CANDY_ARR_SIZE)
{
    _name = name;
    _character = character;
    _stamina = stam;
    _gold = gold;
    _effect = effect;
    _candy_amount = 0;
    for (int i = 0; i < CANDY_ARR_SIZE && _candy_amount < _MAX_CANDY_AMOUNT; i++)
    {
        if (candy_array[i].name != "")
        {
            _inventory[_candy_amount++] = candy_array[i];
        }
    }
};

string Player::getName(){
    return _name;
}
void Player::setName(string name){
    _name=name;
}
string Player::getCharacter(){
    return _character;
}
void Player::setCharacter(string character){
    _character=character;
}
int Player::getCandyAmount()
{
    return _candy_amount;
}
void Player::setCandyAmount(int candy)
{
    _candy_amount = candy;
}
void Player::setStamina(int stam)
{
    _stamina = stam;
}
int Player::getStamina()
{
    return _stamina;
}
void Player::setGold(double gold)
{
    _gold = gold;
}
double Player::getGold()
{
    return _gold;
}
void Player::setEffect(string effect)
{
    _effect = effect;
}
string Player::getEffect()
{
    return _effect;
}

void Player::printInventory()
{
    string name;
    for (int i = 0; i < _MAX_CANDY_AMOUNT; i++)
    {
        name = _inventory[i].name;
        if (i % 3 == 0)
        {
            if (name == "")
            {
                name = "Empty";
            }

            cout << "|[" << name << "]|  " << endl;
        }
        else
        {
            if (name == "")
            {
                name = "Empty";
            }
            cout << "|[" << name << "]  ";
        }
    }
    return;
}

Candy Player::findCandy(string candy_name)
{
    string test = "";
    for (unsigned int j = 0; j < candy_name.length(); j++)
    {
        candy_name[j] = tolower(candy_name[j]);
    }
    for (int i = 0; i < _candy_amount; i++)
    {
        test = _inventory[i].name;
        for (unsigned int j = 0; j < _inventory[i].name.length(); j++)
        {
            test[j] = tolower(_inventory[i].name[j]);
        }
        if (test == candy_name)
        {
            return _inventory[i];
        }
    }
    Candy T;
    return T;
}

bool Player::addCandy(Candy C)
{
    if (_candy_amount < _MAX_CANDY_AMOUNT)
    {
        _inventory[_candy_amount++] = C;
        return true;
    }
    else
    {
        return false;
    }
}

bool Player::removeCandy(string candy_name)
{
    string test;
    Candy temp = findCandy(candy_name);
    for (unsigned int j = 0; j < candy_name.length(); j++)
    {
        candy_name[j] = tolower(candy_name[j]);
    }
    for (int i = 0; i < _candy_amount; i++)
    {
        test = _inventory[i].name;
        for (unsigned int j = 0; j < _inventory[i].name.length(); j++)
        {
            test[j] = tolower(_inventory[i].name[j]);
        }

        if (test == candy_name)
        {
            for (int j = i; j < _candy_amount - 1; j++)
            {
                _inventory[j] = _inventory[j + 1];
            }
            Candy T;
            _inventory[_candy_amount - 1] = T;
            _candy_amount--;
            return true;
        }
    }
    return false;
}

/*
bool Player:: swapCandy(Candy gain, Candy lose){
    //replace the lost candy with the gained one 
}

*/