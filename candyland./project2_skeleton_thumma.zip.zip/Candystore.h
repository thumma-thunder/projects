#ifndef CANDYSTORE_H
#define CANDYSTORE_H
#include "Board.h"
#include <iostream>
#include <vector>
using namespace std;



class Candystore{
    private:
        const static int _MAX_CANDIES=3;
        string _storeName;
        Candy _storeStock[_MAX_CANDIES];
        int _candy_count=0;

    public:
        Candystore();
        Candystore(string,Candy[],const int);
        string getName();
        void setName(string);
        void addCandy(Candy);
        void removeCandy(string);
        void displayCandy();
        Candy findCandy();
};


#endif