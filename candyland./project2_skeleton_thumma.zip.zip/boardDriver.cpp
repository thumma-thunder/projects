#include "Candystore.h"
#include "Player.h"
#include <iostream>
#include <vector>
#include <cassert>
using namespace std;

void playRockPaperScissors(Player players[2])
{
    bool zeroone;
    string bet1;
    string bet2;
    string choice1;
    string choice2;
    string bet10 = "";
    string bet20 = "";
    Candy Bet2;
    Candy Bet1;
    if (players[0].getCandyAmount() == 0 || players[1].getCandyAmount() == 0)
    {
        cout << "Not enough candy!" << endl;
    }
    else
    {
        cout << "Player 1 Inventory" << endl;
        players[0].printInventory();
        cout << "Player 1: Select candy to bet" << endl;
        getline(cin, bet1);
        while (cin.fail())
        {
            cout << "Invalid selection!" << endl;
            cin.clear();
            getline(cin, bet1);
            cin.ignore(1000000, '\n');
        }
        bet10 = bet1;
        for (unsigned int j = 0; j < bet1.length(); j++)
        {
            bet10[j] = tolower(bet1[j]);
        }
        Bet1 = players[0].findCandy(bet1);
        while (bet10 != Bet1.name)
        {
            cout << "Invalid selection!" << endl;
            getline(cin, bet1);
            bet10 = bet1;
            for (unsigned int j = 0; j < bet1.length(); j++)
            {
                bet10[j] = tolower(bet1[j]);
            }
            Bet1 = players[0].findCandy(bet1);
        }
        cout << "Player 2 Inventory" << endl;
        players[1].printInventory();
        cout << "Player 2: Select candy to bet" << endl;
        getline(cin, bet2);
        while (cin.fail())
        {
            cin.ignore(1000000, '\n');
            cout << "Invalid selection!" << endl;
            cin.clear();
            getline(cin, bet2);
            cin.ignore(1000000, '\n');
        }
        bet20 = bet2;

        for (unsigned int j = 0; j < bet2.length(); j++)
        {
            bet20[j] = tolower(bet2[j]);
        }
        Bet2 = players[1].findCandy(bet2);
        while (bet20 != Bet2.name)
        {
            cout << "Invalid selection!" << endl;
            getline(cin, bet2);
            bet20 = bet2;
            for (unsigned int j = 0; j < bet2.length(); j++)
            {
                bet20[j] = tolower(bet2[j]);
            }
            Bet2 = players[1].findCandy(bet2);
        }
        cout << "Player 1: Enter r, p, or s" << endl;
        getline(cin, choice1);

        while (choice1 != "r" && choice1 != "p" && choice1 != "s")
        {
            cout << "Invalid selection!" << endl;
            cin.clear();
            getline(cin, choice1);
        }
        cout << "Player 2: Enter r, p, or s" << endl;
        getline(cin, choice2);
        while (choice2 != "r" && choice2 != "p" && choice2 != "s")
        {
            cout << "Invalid selection!" << endl;
            cin.clear();
            getline(cin, choice2);
        }
        while (choice1 == choice2)
        {
            cout << "Tie! Play again" << endl;
            cout << "Player 1: Enter r, p, or s" << endl;
            getline(cin, choice1);

            while (choice1 != "r" && choice1 != "p" && choice1 != "s")
            {
                cout << "Invalid selection!" << endl;
                cin.clear();
                getline(cin, choice1);
            }
            cout << "Player 2: Enter r, p, or s" << endl;
            getline(cin, choice2);
            while (choice2 != "r" && choice2 != "p" && choice2 != "s")
            {
                cout << "Invalid selection!" << endl;
                cin.clear();
                getline(cin, choice2);
            }
        }
        if ((choice1 == "r" && choice2 == "s") || (choice1 == "p" && choice2 == "r") || (choice1 == "s" && choice2 == "p"))
        {
            zeroone = false;
        }
        else if ((choice1 == "r" && choice2 == "p") || (choice1 == "p" && choice2 == "s") || (choice1 == "s" && choice2 == "r"))
        {
            zeroone = true;
        }

        if (zeroone == false)
        {
            string pls1 = Bet2.name;
            cout << "Player 1 has won " << bet2 << " from player 2!" << endl;
            players[1].removeCandy(pls1);
            players[0].addCandy(Bet2);
        }
        else
        {
            string pls2 = Bet1.name;
            cout << "Player 2 has won " << bet1 << " from player 1!" << endl;
            players[0].removeCandy(pls2);
            players[1].addCandy(Bet1);
        }
    }
}

vector<string> loadRiddles();
// Loads riddles into a vector of strings using getline

vector<Candy> loadCandies(string file);
// Load all the candies from the file and store them as their own candy structures using getline
// Returns vector of candies

void addcandies(string candies[], Candy candy[], vector<Candy> candie);
// find every candy name string as a candy in the vector of candies that was loaded in
// Add these candies to the candy array

vector<Player> loadCharacters(string file, vector<Candy> candies);
// Load atleast 4 characters and return vector of players
// Use getline looping to retrieve all the data from  file
// store candy names as vector of strings, initialize empty array that is the same size as candies in line(vector of candy)
// Pass array of strings and empty candy array along with vector of candies

bool solveRiddle(vector<string> Riddles);
// Cout the riddles randomly and return true if they solve it
string drawCard();
// string cards[6]={"BBlue","Minty Green", "Poverty Pink","Double Bubblegum Blue", "Double Minty Green", "Double Poverty Pink"};
// srand time stuff to draw a random card, 75% chance of a single card and 25% of double, equal chance between which color you get

int moveTo(int position, string card);
// Calulates new position and takes old position of player and the card they drew as input
// Use modulus 3 to find out what color tile you are on  (0= magenta 1=green 2=blue)
// return the amount the player needs to move to use movePlayer() in the main

Player choosePlayer(vector<Player> Players);
/*call display player for each player(2) and add a break(------)
string choice;
cout << "The character selected is" << endl;
getline(cin, choice);
//error handling
//algorithm to find player in vector and return them/send them to back to be popped out
*/

bool isCalamity();
// Chance stuff

Player whichCalamity(Player);

int main()
{
    int candy_store_idx;
    Board board;
    board.displayBoard();
    // Make candies/inventories
    Candy one{"Frosty Fizz", "Boosts player's stamina by 10 units", "stamina", 10, "magical", 10};
    Candy two{"Toxic Taffy", "Decreases opponents stamina by 20 units(strong)", "stamina", -20, "poison", 25};
    Candy three{"Caramel Comet", "Protects against all poison candies", "other", 3, "immunity", 25};
    Candy four{"Swedish Fish", "Does nothing", "other", 5, "play fortnite", 23};
    Candy five{"Kelpish Fish", "Does something", "stamina", 23, "play fortnite", 32};
    Candy six{"Norwegian Fish", "Does everything", "other", 13, "play fortnite", 98};

    Candy oneInv[3] = {one, two, four};
    Candy twoInv[3] = {two, six, five};
    Candy threeInv[3] = {five, three, two};

    Candy playercandy[9] = {six, five, one, two, three, five, six, three, two};

    Player Player{"Lebron James", "Michelle Obama", 12, 12, "fast", playercandy, 9};

    (assert(Player.getName() == "Lebron James"));
    (assert(Player.getStamina() == 12));
    (assert(Player.getCharacter() == "Michelle Obama"));
    Player.printInventory();

    // Make all candy stores
    Candystore Store1{"Store1", oneInv, 3};
    Candystore Store2{"Store2", twoInv, 3};
    Candystore Store3{"Store3", threeInv, 3};
    Candystore candy_stores[] = {Store1, Store2, Store3};
    // Add the candy stores to baord
    board.addCandyStore(38);
    board.addCandyStore(58);
    board.addCandyStore(69);
    (assert(Store1.getName() == "Store1"));
    Store2.setName("Obama");
    (assert(Store2.getName() == "Obama"));

    for (int i = 0; i < board.getBoardSize(); i++)
    {
        board.setPlayerPosition(i);
        if (board.isPositionCandyStore(i))
        {
            cout << endl;
            board.displayBoard();
            candy_store_idx = board.getCandyStoreIndex(i);
            candy_stores[candy_store_idx].displayCandy();
        }
    }

    return 0;
}