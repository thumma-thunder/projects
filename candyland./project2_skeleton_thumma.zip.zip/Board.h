#ifndef BOARD_H
#define BOARD_H

#include <iostream>
#include <vector>
#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define ORANGE "\033[48;2;230;115;0m"  /* Orange (230,115,0)*/
#define RESET "\033[0m"

using namespace std;

struct Candy
{ 
    string name;
    string description;
    string effect_type;
    int effect_value;
    string candy_type;
    double price;
};



struct Tile
{
    string color;
    string tile_type;
};


class Board
{
private:
    //Board tiles
    const static int _BOARD_SIZE = 83;
    Tile _tiles[_BOARD_SIZE];
    //Candystore tiles
    const static int _MAX_CANDY_STORE = 3;
    int _candy_store_position[_MAX_CANDY_STORE];
    int _candy_store_count;
    int _player_position; //[2] Array of players to allow two players to play
    

    //Treasure Tiles
    const static int _MAX_TREASURE = 3;
    int _treasure_position[_MAX_TREASURE];
    int _treasure_count;


public:
    Board();

    void resetBoard();
    void displayTile(int);
    void displayBoard();

    bool setPlayerPosition(int); //add another int as input that is index (0 for player 1, 1 for player 2)

    int getBoardSize() const;
    int getCandyStoreCount() const;
    int getPlayerPosition() const;
    int getCandyStoreIndex(int board_position);

    bool addCandyStore(int);
    bool isPositionCandyStore(int); 

    bool isTileSpecial(int);
    bool isTileTreasure(int);

    bool movePlayer(int tile_to_move_forward);

    bool addTreasure(int);
    int getTreasureCount() const;
    
};

#endif